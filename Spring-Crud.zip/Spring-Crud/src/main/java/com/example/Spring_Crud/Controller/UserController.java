package com.example.Spring_Crud.Controller;

import java.security.PublicKey;
import java.util.*;

import com.example.Spring_Crud.Entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Spring_Crud.Repository.UserRepo;

@Controller
@RequestMapping("/users")
public class UserController {

	 @Autowired
	 private UserRepo userRepository;
	 
	 @GetMapping
	    public String getAllUsers(Model model) {
	        model.addAttribute("users", userRepository.findAll());
	        return "user_list";
	    }

	    @GetMapping("/new")
	    public String showCreateUserForm(Model model) {
	        model.addAttribute("user", new User());
	        return "create_user";
	    }

	    @PostMapping
	    public String createUser(@ModelAttribute User user) {
	        userRepository.save(user);
	        return "redirect:/users";
	    }

	    @GetMapping("/edit/{id}")
	    public String showEditUserForm(@PathVariable Long id, Model model) {
	        User user = userRepository.findById(id).orElse(null);
	        model.addAttribute("user", user);
	        return "edit_user";
	    }

	    @PostMapping("/update/{id}")
	    public String updateUser(@PathVariable Long id, @ModelAttribute User userDetails) {
	        User user = userRepository.findById(id).orElse(null);
	        if (user != null) {
	            user.setName(userDetails.getName());
	            user.setEmail(userDetails.getEmail());
	            user.setMobile(userDetails.getMobile());
	            user.setAddress(userDetails.getAddress());
	            userRepository.save(user);
	        }
	        return "redirect:/users";
	    }

	    @GetMapping("/delete/{id}")
	    public String deleteUser(@PathVariable Long id) {
	        userRepository.deleteById(id);
	        return "redirect:/users";
	    }
	
	
	
}
