package com.example.Spring_Crud.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.Spring_Crud.Entity.User;

public interface UserRepo  extends JpaRepository<User,Long> {

}
